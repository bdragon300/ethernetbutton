#include <avr/io.h>
#include "lan.h"
#include "counter.h"

void udp_packet(eth_frame_t *frame, uint16_t len)
{
}

int main()
{
	_delay_ms(20);

	DDRA |= (1<<PA0);
	PORTA |= (1<<PA0);
	lan_init();

	counter_init();
	sei();

	while(1)
	{
		lan_poll();

		if(lan_up())
			PORTA &= ~(1<<PA0);
		else
			PORTA |= (1<<PA0);
	}
	
	return 0;
}
